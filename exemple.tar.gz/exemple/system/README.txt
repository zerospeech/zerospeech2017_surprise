
uname -a:
Linux machine-xyz 4.4.0-77-generic #98-Ubuntu SMP Wed Apr 26 08:34:02 UTC 2017 x86_64 x86_64 x86_64 GNU/Linux

sudo lshw -short:

H/W path       Device     Class          Description
====================================================
                          system         machine-xyz 
/0                        bus            09WH54
/0/0                      memory         64KiB BIOS
/0/18                     processor      Intel(R) Core(TM) i5-6500 CPU @ 3.20GHz
/0/18/15                  memory         256KiB L1 cache
/0/18/16                  memory         1MiB L2 cache
/0/18/17                  memory         6MiB L3 cache
/0/14                     memory         256KiB L1 cache
/0/19                     memory         16GiB System Memory
/0/19/0                   memory         8GiB DIMM Synchronous 2133 MHz (0,5 ns)
/0/19/1                   memory         8GiB DIMM Synchronous 2133 MHz (0,5 ns)
/0/19/2                   memory         [empty]
/0/19/3                   memory         [empty]
/0/100                    bridge         Sky Lake Host Bridge/DRAM Registers
/0/100/1                  bridge         Sky Lake PCIe Controller (x16)
/0/100/1/0                display        GF119 [NVS 315]
/0/100/1/0.1              multimedia     GF119 HDMI Audio Controller
/0/100/14                 bus            Sunrise Point-H USB 3.0 xHCI Controller
/0/100/14/0    usb2       bus            xHCI Host Controller
/0/100/14/1    usb1       bus            xHCI Host Controller
/0/100/14/1/6             input          Dell MS116 USB Optical Mouse
/0/100/14/1/8             input          Dell KB216 Wired Keyboard
/0/100/14.2               generic        Sunrise Point-H Thermal subsystem
/0/100/16                 communication  Sunrise Point-H CSME HECI #1
/0/100/16.3               communication  Sunrise Point-H KT Redirection
/0/100/17                 storage        Sunrise Point-H SATA controller [AHCI mode]
/0/100/1c                 bridge         Sunrise Point-H PCI Express Root Port #1
/0/100/1c/0               bridge         XIO2001 PCI Express-to-PCI Bridge
/0/100/1f                 bridge         Sunrise Point-H LPC Controller
/0/100/1f.2               memory         Memory controller
/0/100/1f.3               multimedia     Sunrise Point-H HD Audio
/0/100/1f.4               bus            Sunrise Point-H SMBus
/0/100/1f.6    eth0       network        Ethernet Connection (2) I219-LM
/0/1           scsi0      storage        
/0/1/0.0.0     /dev/sda   disk           500GB WDC WD5000AZLX-7
/0/1/0.0.0/1              volume         511MiB Windows FAT volume
/0/1/0.0.0/2   /dev/sda2  volume         449GiB EXT4 volume
/0/1/0.0.0/3   /dev/sda3  volume         15GiB Linux swap volume
