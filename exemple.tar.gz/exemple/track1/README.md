Command used for track1 is (from the system directory):

    some_command -a 1 -b 2 /path/to/surprise_data /path/to/results/track1
